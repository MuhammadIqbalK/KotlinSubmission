package id.infinitelearning.KotlinSubmission.exercise1

import org.junit.jupiter.api.Test

import org.junit.jupiter.api.Assertions.*

internal class AppKtTest {

    @Test
    fun groupDetail() {

    }

    @Test
    fun main() {
    }
}